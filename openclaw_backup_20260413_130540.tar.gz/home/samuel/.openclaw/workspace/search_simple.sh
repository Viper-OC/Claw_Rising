#!/bin/bash
CONFIG="/home/samuel/.openclaw/workspace/himalaya_config.toml"
SENDER="shorttermrental@charlestoncounty.org"
CUTOFF="2025-03-31"
QUERY="from $SENDER and after $CUTOFF"

echo "Searching for emails from $SENDER after $CUTOFF"
echo ""

# Get folder list using plain output (table), extract first column
folders=$(himalaya --config "$CONFIG" folder list | awk 'NR>1 {print $1}' | head -20)

for folder in $folders; do
    echo "=== Folder: $folder ==="
    # Use plain output; if there are results, a table will be printed
    himalaya --config "$CONFIG" envelope list --folder "$folder" --page-size 20 "$QUERY" 2>/dev/null | grep -v "WARN" | head -20
    echo ""
done