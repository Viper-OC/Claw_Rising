# USER.md - About Your Human

_Learn about the person you're helping. Update this as you go._

- **Name:** Sam Britton
- **What to call them:** Sam
- **Pronouns:** _(optional)_
- **Timezone:** Pacific/Auckland (NZDT, UTC+13 during daylight saving)
- **Host timezone:** America/New_York (EDT/EST) – OpenClaw server location
- **Notes:** Business travel through March 26, 2026. Currently in Auckland, New Zealand daylight saving time.

## Context

_(What do they care about? What projects are they working on? What annoys them? What makes them laugh? Build this over time.)_

---

The more you know, the better you can help. But remember — you're learning about a person, not building a dossier. Respect the difference.
