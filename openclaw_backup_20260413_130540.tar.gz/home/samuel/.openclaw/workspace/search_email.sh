#!/bin/bash
set -e

CONFIG="/home/samuel/.openclaw/workspace/himalaya_config.toml"
SENDER="shorttermrental@charlestoncounty.org"
CUTOFF="2025-03-31"
QUERY="from $SENDER and after $CUTOFF"

echo "Searching for emails from $SENDER after $CUTOFF"
echo ""

# Get folder list
FOLDERS=$(himalaya --config "$CONFIG" -o json folder list | jq -r '.[].name')

for folder in $FOLDERS; do
    echo "Checking folder: $folder"
    # Search with larger page size
    result=$(himalaya --config "$CONFIG" -o json envelope list --folder "$folder" --page-size 50 "$QUERY" 2>/dev/null || true)
    if [[ -n "$result" && "$result" != "[]" ]]; then
        echo "Found emails in $folder:"
        echo "$result" | jq -c '.[]' | while read -r email; do
            subject=$(echo "$email" | jq -r '.subject')
            date=$(echo "$email" | jq -r '.date')
            from=$(echo "$email" | jq -r '.from.addr')
            echo "  Subject: $subject"
            echo "  Date: $date"
            echo "  From: $from"
            echo ""
        done
    fi
done

echo "Search complete."