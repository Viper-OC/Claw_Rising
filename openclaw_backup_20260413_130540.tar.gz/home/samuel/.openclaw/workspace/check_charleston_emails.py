#!/usr/bin/env python3
"""
Weekly check for new emails from shorttermrental@charlestoncounty.org.
Sends Telegram notification if new emails found.
"""
import subprocess
import json
import os
import sys
import argparse
from datetime import datetime, timezone
import traceback

# Configuration
CONFIG_PATH = '/home/samuel/.openclaw/workspace/himalaya_config.toml'
STATE_FILE = '/home/samuel/.openclaw/workspace/state/charleston_check.date'
SENDER = 'shorttermrental@charlestoncounty.org'
TELEGRAM_TARGET = '8539209616'  # Sam's Telegram chat id

def run_himalaya(args):
    """Run himalaya command and return parsed JSON output."""
    cmd = ['himalaya', '--config', CONFIG_PATH, '-o', 'json'] + args
    # Ensure himalaya is in PATH
    env = os.environ.copy()
    env['PATH'] = f"/home/samuel/.local/bin:{env.get('PATH', '')}"
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, env=env)
        # Filter out warning lines (they start with timestamp)
        lines = [line for line in result.stdout.split('\n') if not line.startswith('[')]
        output = '\n'.join(lines).strip()
        if not output:
            return []
        if output.startswith('['):
            return json.loads(output)
        else:
            return [json.loads(output)]
    except json.JSONDecodeError as e:
        print(f"JSON decode error: {e}", file=sys.stderr)
        print(f"Output: {output}", file=sys.stderr)
        return []
    except Exception as e:
        print(f"Error running himalaya: {e}", file=sys.stderr)
        return []

def send_telegram(message, dry_run=False):
    """Send a message via OpenClaw Telegram."""
    if dry_run:
        print(f"[DRY RUN] Would send Telegram: {message[:100]}...")
        return True
    cmd = ['openclaw', 'message', 'send', '--channel', 'telegram',
           '--target', TELEGRAM_TARGET, '--message', message]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True)
        if result.returncode != 0:
            print(f"Failed to send Telegram: {result.stderr}", file=sys.stderr)
            return False
        print("Telegram sent successfully.")
        return True
    except Exception as e:
        print(f"Exception sending Telegram: {e}", file=sys.stderr)
        return False

def read_last_check():
    """Read last check date from state file (YYYY-MM-DD)."""
    try:
        with open(STATE_FILE, 'r') as f:
            line = f.readline().strip()
            # Validate format
            datetime.strptime(line, '%Y-%m-%d')
            return line
    except FileNotFoundError:
        # First run: use today's date (UTC) minus one day to catch any recent emails
        today = datetime.now(timezone.utc).date()
        default = today.isoformat()
        with open(STATE_FILE, 'w') as f:
            f.write(default + '\n')
        return default
    except Exception as e:
        print(f"Error reading state file: {e}", file=sys.stderr)
        # Fallback to today
        today = datetime.now(timezone.utc).date().isoformat()
        return today

def update_last_check(date=None):
    """Update state file with given date (YYYY-MM-DD) or today UTC."""
    if date is None:
        date = datetime.now(timezone.utc).date().isoformat()
    try:
        with open(STATE_FILE, 'w') as f:
            f.write(date + '\n')
        print(f"Updated last check date to {date}")
        return True
    except Exception as e:
        print(f"Error updating state file: {e}", file=sys.stderr)
        return False

def main():
    parser = argparse.ArgumentParser(description='Check for new emails from Charleston County.')
    parser.add_argument('--dry-run', action='store_true', help='Do not send Telegram, just print.')
    args = parser.parse_args()
    
    print(f"Starting check for emails from {SENDER}")
    last_check = read_last_check()
    print(f"Last check date: {last_check}")
    
    # Query emails after last_check date
    query = f'from {SENDER} and after {last_check}'
    # Search all folders? For simplicity, just INBOX
    emails = run_himalaya(['envelope', 'list', '--folder', 'INBOX',
                           '--page-size', '50', query])
    
    if not emails:
        print("No new emails found.")
        # Still update last check date to today (so we don't keep checking same period)
        update_last_check()
        return 0
    
    # Sort by date ascending (oldest first)
    emails.sort(key=lambda x: x.get('date', ''))
    print(f"Found {len(emails)} new email(s).")
    
    # Build notification message
    lines = [f"📧 New email(s) from {SENDER}:"]
    for i, e in enumerate(emails, 1):
        subject = e.get('subject', 'No subject')
        date = e.get('date', 'Unknown date')
        # Truncate subject if too long
        if len(subject) > 80:
            subject = subject[:77] + '...'
        lines.append(f"{i}. {date} — {subject}")
    
    # Add total count
    lines.append(f"\nTotal: {len(emails)} new email(s).")
    message = '\n'.join(lines)
    
    # Send notification
    success = send_telegram(message, dry_run=args.dry_run)
    if success:
        # Update last check date to today (UTC) after successful notification
        update_last_check()
        print("Notification sent and state updated.")
    else:
        print("Failed to send notification; state not updated.")
        return 1
    
    return 0

if __name__ == '__main__':
    try:
        sys.exit(main())
    except Exception as e:
        print(f"Unhandled error: {e}", file=sys.stderr)
        traceback.print_exc()
        sys.exit(1)