#!/usr/bin/env python3
import subprocess
import json
import sys

config = '/home/samuel/.openclaw/workspace/himalaya_config.toml'
sender = 'shorttermrental@charlestoncounty.org'
cutoff = '2025-03-31'
query = f'from {sender} and after {cutoff}'

# Get folders
cmd = ['himalaya', '--config', config, '-o', 'json', 'folder', 'list']
result = subprocess.run(cmd, capture_output=True, text=True, shell=False)
if result.returncode != 0:
    print("Failed to get folders", file=sys.stderr)
    sys.exit(1)
# Filter warnings
lines = [line for line in result.stdout.split('\n') if not line.startswith('[')]
output = '\n'.join(lines).strip()
folders = json.loads(output) if output else []
print(f"Checking {len(folders)} folders...")
found = []
for folder in folders:
    name = folder['name']
    cmd = ['himalaya', '--config', config, '-o', 'json', 'envelope', 'list', '--folder', name, '--page-size', '50', query]
    res = subprocess.run(cmd, capture_output=True, text=True)
    lines = [line for line in res.stdout.split('\n') if not line.startswith('[')]
    out = '\n'.join(lines).strip()
    if out and out != '[]':
        emails = json.loads(out)
        for e in emails:
            e['folder'] = name
            found.append(e)
            print(f"Found in {name}: {e.get('date')} - {e.get('subject')}")

print(f"\nTotal found: {len(found)}")
if found:
    print("\nDetails:")
    for e in found:
        print(f"Folder: {e['folder']}")
        print(f"  Date: {e.get('date')}")
        print(f"  Subject: {e.get('subject')}")
        print(f"  From: {e.get('from', {}).get('addr')}")
        print()