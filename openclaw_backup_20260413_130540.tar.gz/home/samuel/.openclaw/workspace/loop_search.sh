#!/bin/bash
CONFIG="/home/samuel/.openclaw/workspace/himalaya_config.toml"
SENDER="shorttermrental@charlestoncounty.org"
CUTOFF="2025-03-31"
QUERY="from $SENDER and after $CUTOFF"

folders=$(himalaya --config "$CONFIG" -o json folder list 2>/dev/null | grep -v "WARN" | jq -r '.[].name')

for folder in $folders; do
    echo "=== $folder ==="
    himalaya --config "$CONFIG" -o json envelope list --folder "$folder" --page-size 30 "$QUERY" 2>/dev/null | grep -v "WARN" | jq -r '.[] | "\(.date) | \(.subject)"'
done