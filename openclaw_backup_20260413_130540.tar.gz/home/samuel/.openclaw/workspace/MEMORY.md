# MEMORY.md – Long‑Term Memory

Curated memories, decisions, and lessons learned.

## 2026‑03‑23

- **Projects directory created** – Structured `workspace/projects/` with templates, index, and registry.
  - Simple backup‑only flow for now; individual git repos per project when coding begins.
  - Specialist agent persistence configured (`archiveAfterMinutes: 120`).
- **Team‑of‑agents capability** – Sub‑agent nesting (`maxSpawnDepth: 2`) available when configured.
- **User identified** – Sam Britton, timezone America/New_York.

---

## 2026‑03‑31

- **Pantry Pilot project initialized** – Created project folder and index entry; awaiting intent.

---

*This file is updated periodically from daily memory logs.*