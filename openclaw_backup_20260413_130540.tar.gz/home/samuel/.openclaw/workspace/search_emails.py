#!/usr/bin/env python3
import subprocess
import json
import sys
from datetime import datetime

def run_himalaya(args):
    """Run himalaya command and return parsed JSON output."""
    cmd = ['himalaya', '--config', '/home/samuel/.openclaw/workspace/himalaya_config.toml', '-o', 'json'] + args
    # Ensure himalaya is in PATH
    env = {'PATH': f"{subprocess.os.environ.get('HOME')}/.local/bin:{subprocess.os.environ.get('PATH')}"}
    print(f"Running: {' '.join(cmd)}", file=sys.stderr)
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, env=env)
        print(f"stderr: {result.stderr[:200]}", file=sys.stderr)
        # Filter out warning lines (they start with timestamp)
        lines = [line for line in result.stdout.split('\n') if not line.startswith('[')]
        output = '\n'.join(lines).strip()
        print(f"output: {output[:200]}", file=sys.stderr)
        if not output:
            return []
        # Sometimes multiple JSON objects may be concatenated; wrap in array if needed
        if output.startswith('['):
            return json.loads(output)
        else:
            # Single object
            return [json.loads(output)]
    except json.JSONDecodeError as e:
        print(f"JSON decode error: {e}", file=sys.stderr)
        print(f"Output: {output}", file=sys.stderr)
        return []
    except Exception as e:
        print(f"Error running himalaya: {e}", file=sys.stderr)
        return []

def main():
    sender = 'shorttermrental@charlestoncounty.org'
    date_cutoff = '2025-03-31'
    
    # Get folder list
    folders = run_himalaya(['folder', 'list'])
    if not folders:
        print("Failed to get folder list", file=sys.stderr)
        sys.exit(1)
    
    print(f"Searching folders for emails from {sender} after {date_cutoff}...")
    all_emails = []
    
    for folder in folders:
        folder_name = folder['name']
        # Skip Sent Messages? We'll search all.
        query = f'from {sender} and after {date_cutoff}'
        args = ['envelope', 'list', '--folder', folder_name, '--page-size', '50', query]
        emails = run_himalaya(args)
        if emails:
            for email in emails:
                email['folder'] = folder_name
                all_emails.append(email)
    
    # Sort by date descending
    all_emails.sort(key=lambda x: x.get('date', ''), reverse=True)
    
    print(f"\nFound {len(all_emails)} email(s):")
    for email in all_emails:
        print(f"\nFolder: {email['folder']}")
        print(f"  Subject: {email.get('subject', 'N/A')}")
        print(f"  From: {email.get('from', {}).get('addr', 'N/A')}")
        print(f"  Date: {email.get('date', 'N/A')}")
        print(f"  ID: {email.get('id', 'N/A')}")
    
    # Optionally save to JSON file
    with open('search_results.json', 'w') as f:
        json.dump(all_emails, f, indent=2)
    print(f"\nResults saved to search_results.json")

if __name__ == '__main__':
    main()