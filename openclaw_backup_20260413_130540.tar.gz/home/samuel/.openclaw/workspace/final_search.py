#!/usr/bin/env python3
import subprocess
import json
import os
import sys

def run_himalaya(args):
    """Run himalaya command and return parsed JSON output."""
    cmd = ['himalaya', '--config', '/home/samuel/.openclaw/workspace/himalaya_config.toml', '-o', 'json'] + args
    env = os.environ.copy()
    env['PATH'] = f"/home/samuel/.local/bin:{env.get('PATH', '')}"
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, env=env)
        # Filter out warning lines (they start with timestamp)
        lines = [line for line in result.stdout.split('\n') if not line.startswith('[')]
        output = '\n'.join(lines).strip()
        if not output:
            return []
        if output.startswith('['):
            return json.loads(output)
        else:
            return [json.loads(output)]
    except json.JSONDecodeError:
        # If output is not JSON, maybe error
        return []
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return []

def main():
    sender = 'shorttermrental@charlestoncounty.org'
    cutoff = '2025-03-31'
    query = f'from {sender} and after {cutoff}'
    
    folders = run_himalaya(['folder', 'list'])
    if not folders:
        print("Failed to get folders", file=sys.stderr)
        sys.exit(1)
    
    print(f"Searching for emails from {sender} after {cutoff}")
    print()
    
    found = []
    for folder in folders:
        folder_name = folder['name']
        emails = run_himalaya(['envelope', 'list', '--folder', folder_name, '--page-size', '50', query])
        if emails:
            for email in emails:
                email['folder'] = folder_name
                found.append(email)
    
    # Sort by date descending
    found.sort(key=lambda x: x.get('date', ''), reverse=True)
    
    if not found:
        print("No emails found.")
    else:
        print(f"Found {len(found)} email(s):")
        for email in found:
            print(f"\nFolder: {email['folder']}")
            print(f"  Subject: {email.get('subject', 'N/A')}")
            print(f"  From: {email.get('from', {}).get('addr', 'N/A')}")
            print(f"  Date: {email.get('date', 'N/A')}")
            print(f"  ID: {email.get('id', 'N/A')}")
    
    # Save to file
    with open('search_results.json', 'w') as f:
        json.dump(found, f, indent=2)

if __name__ == '__main__':
    main()