# Project Notes

Raw thoughts, links, references, and brainstorming.

## Links

- [Example resource](https://example.com)

## Ideas

- Bullet point ideas here

## Questions

- What needs clarification?

## Decisions

- **YYYY‑MM‑DD:** Decision made about X.

---

*This file is for unstructured notes. Keep it messy.*