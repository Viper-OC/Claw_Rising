# Project Title

*One‑line elevator pitch.*

## Overview

What problem does this solve? Who is it for? What’s the core value?

## Goals

- Primary objective 1
- Primary objective 2
- Stretch goals (if any)

## Non‑Goals

What’s explicitly out of scope?

## Components

| Component | Purpose | Tech/Stack |
|-----------|---------|------------|
| Frontend  | …       | …          |
| Backend   | …       | …          |
| Database  | …       | …          |
| APIs      | …       | …          |

## Stack

- **Language:**
- **Framework:**
- **Database:**
- **Deployment:**
- **Monitoring:**

## Next Steps

1. [ ] Write detailed spec (SPEC.md)
2. [ ] Create wireframes/mockups
3. [ ] Set up development environment
4. [ ] Spawn coding specialist agent
5. [ ] Begin MVP implementation

---

**Created:** YYYY‑MM‑DD  
**Status:** 💡 Idea / 🚧 Active / ✅ Completed  
**Owner:** [Your Name]