# Projects Index

Master list of all project ideas and active builds.

| Project | Status | Description | Last Updated |
|---------|--------|-------------|--------------|
| [project-alpha](./project-alpha/README.md) | 💡 Idea | *First idea placeholder* | 2026-03-23 |

---

## Adding a new project

1. Duplicate the template:
   ```bash
   cp -r projects/templates projects/your-project-name
   ```
2. Edit `projects/your-project-name/README.md` with your idea.
3. Update this index table.
4. (Optional) Spawn a dedicated specialist agent with the project directory as its `cwd`.

## Active specialist sessions

See [`registry.json`](./registry.json) for live session keys and labels.

---

*Projects are backed up via the periodic `openclaw_backup_*.tar.gz` tarballs pushed to GitHub.*