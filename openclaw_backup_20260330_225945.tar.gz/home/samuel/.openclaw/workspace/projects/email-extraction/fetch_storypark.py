#!/usr/bin/env python3
"""
Fetch latest 5 emails from noreply@storypark.com and extract metadata + body.
Output JSON array of emails.
"""
import subprocess
import json
import sys
import os
import time
from datetime import datetime, timedelta, timezone

def run_himalaya(args):
    """Run himalaya command and return stdout as string."""
    cmd = [os.path.expanduser('~/.local/bin/himalaya')] + args
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=45)
        if result.returncode != 0:
            print(f"Error running himalaya: {result.stderr}", file=sys.stderr)
            return None
        return result.stdout
    except subprocess.TimeoutExpired:
        print("Timeout running himalaya", file=sys.stderr)
        return None
    except Exception as e:
        print(f"Exception: {e}", file=sys.stderr)
        return None

def get_envelopes():
    """Fetch envelopes from noreply@storypark.com."""
    # Fetch recent emails (last 30 days) and filter locally because 'from' filter may miss some
    # Use date filter to reduce load
    thirty_days_ago = (datetime.now(timezone.utc) - timedelta(days=30)).strftime('%Y-%m-%d')
    args = ['envelope', 'list', '--folder', 'INBOX', '--output', 'json', '--page-size', '500', f'after {thirty_days_ago}']
    out = run_himalaya(args)
    if out is None:
        return []
    # Parse JSON
    try:
        envelopes = json.loads(out)
    except json.JSONDecodeError as e:
        print(f"JSON decode error: {e}", file=sys.stderr)
        return []
    # Filter by sender address
    target_sender = 'noreply@storypark.com'
    filtered = []
    for env in envelopes:
        from_addr = env.get('from', {}).get('addr', '')
        if from_addr == target_sender:
            filtered.append(env)
    # Sort by date descending (newest first)
    filtered.sort(key=lambda e: e.get('date', ''), reverse=True)
    print(f"Found {len(filtered)} emails from {target_sender} in last 30 days", file=sys.stderr)
    return filtered

def get_message_body(msg_id):
    """Read full message content by ID."""
    args = ['message', 'read', '--folder', 'INBOX', msg_id]
    out = run_himalaya(args)
    return out

def main():
    envelopes = get_envelopes()
    if not envelopes:
        print("No envelopes found.", file=sys.stderr)
        sys.exit(1)
    
    # Debug: show envelopes before limit
    for i, env in enumerate(envelopes):
        print(f"[{i}] {env.get('date')} {env.get('subject')[:50]}", file=sys.stderr)
    # Limit to latest 5 (already sorted by date descending)
    envelopes = envelopes[:5]
    
    results = []
    for i, env in enumerate(envelopes):
        msg_id = env['id']
        print(f"Processing message {i+1}/{len(envelopes)} (ID {msg_id})", file=sys.stderr)
        body = get_message_body(msg_id)
        # Combine envelope metadata with body
        email_data = {
            'id': msg_id,
            'subject': env.get('subject'),
            'from': env.get('from'),
            'to': env.get('to'),
            'date': env.get('date'),
            'flags': env.get('flags'),
            'has_attachment': env.get('has_attachment'),
            'body': body.strip() if body else None
        }
        results.append(email_data)
        # Small delay between reads to avoid rate limits
        if i < len(envelopes) - 1:
            time.sleep(1)
    
    # Output JSON
    print(json.dumps(results, indent=2))

if __name__ == '__main__':
    main()