#!/usr/bin/env python3
import sys
sys.path.insert(0, '.')
# Import functions from fetch_storypark
from fetch_storypark import get_envelopes, get_message_body, run_himalaya

envelopes = get_envelopes()
print(f"Total envelopes: {len(envelopes)}")
for i, env in enumerate(envelopes[:10]):
    print(f"{i+1}: {env['id']} {env['date']} {env['subject'][:60]}")
print("\nChecking for March 30 email (ID 61572)...")
found = [e for e in envelopes if e['id'] == '61572']
if found:
    print("✓ Found March 30 email")
    print(f"  Date: {found[0]['date']}")
    print(f"  Subject: {found[0]['subject']}")
else:
    print("✗ Not found")
    # Show first 20 IDs
    print("First 20 IDs:", [e['id'] for e in envelopes[:20]])