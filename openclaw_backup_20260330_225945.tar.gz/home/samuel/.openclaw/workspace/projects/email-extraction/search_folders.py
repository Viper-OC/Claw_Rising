#!/usr/bin/env python3
"""
Search all IMAP folders for emails from noreply@storypark.com.
"""
import subprocess
import json
import sys
import os

def run_himalaya(args):
    cmd = [os.path.expanduser('~/.local/bin/himalaya')] + args
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        if result.returncode != 0:
            print(f"Error running himalaya: {result.stderr}", file=sys.stderr)
            return None
        return result.stdout
    except subprocess.TimeoutExpired:
        print("Timeout running himalaya", file=sys.stderr)
        return None
    except Exception as e:
        print(f"Exception: {e}", file=sys.stderr)
        return None

def get_folders():
    """Return list of folder names from himalaya folder list."""
    out = run_himalaya(['folder', 'list'])
    if out is None:
        return []
    folders = []
    lines = out.strip().split('\n')
    # Skip header lines: first two lines are table header and separator
    for line in lines[2:]:
        line = line.strip()
        if not line or line.startswith('+-'):
            continue
        # Parse table row: | FolderName   | Description |
        parts = line.split('|')
        if len(parts) >= 2:
            folder = parts[1].strip()
            if folder:
                folders.append(folder)
    return folders

def search_folder(folder, sender):
    """Return list of envelopes from sender in given folder."""
    args = ['envelope', 'list', '--folder', folder, '--output', 'json', 'from', sender]
    out = run_himalaya(args)
    if out is None:
        return []
    try:
        envelopes = json.loads(out)
        return envelopes
    except json.JSONDecodeError:
        return []

def main():
    sender = 'noreply@storypark.com'
    folders = get_folders()
    print(f"Found {len(folders)} folders", file=sys.stderr)
    for folder in folders:
        envelopes = search_folder(folder, sender)
        if envelopes:
            print(f"\n=== Folder: {folder} ===")
            for env in envelopes:
                print(f"  Date: {env.get('date')}  ID: {env.get('id')}  Subject: {env.get('subject')[:60]}...")
        else:
            print(f".", end='', file=sys.stderr)
    print(file=sys.stderr)

if __name__ == '__main__':
    main()