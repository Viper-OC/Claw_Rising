#!/usr/bin/env python3
import json
import subprocess
import sys
import os

def run_himalaya(args):
    cmd = [os.path.expanduser('~/.local/bin/himalaya')] + args
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        if result.returncode != 0:
            print(f"Error: {result.stderr}", file=sys.stderr)
            return None
        return result.stdout
    except subprocess.TimeoutExpired:
        print("Timeout", file=sys.stderr)
        return None
    except Exception as e:
        print(f"Exception: {e}", file=sys.stderr)
        return None

args = ['envelope', 'list', '--folder', 'INBOX', '--output', 'json', '--page-size', '50', 'from', 'noreply@storypark.com']
out = run_himalaya(args)
if out:
    envelopes = json.loads(out)
    print(f"Total envelopes: {len(envelopes)}")
    envelopes.sort(key=lambda e: e.get('date', ''), reverse=True)
    for i, env in enumerate(envelopes[:10]):
        print(f"{i+1}: {env['id']} {env['date']} {env['subject'][:50]}")
else:
    print("Failed")