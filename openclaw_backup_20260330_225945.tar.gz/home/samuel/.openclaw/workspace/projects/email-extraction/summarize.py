#!/usr/bin/env python3
import json
import sys

with open('storypark_emails.json', 'r') as f:
    data = json.load(f)

print(f"Found {len(data)} emails from Storypark")
print()
for i, email in enumerate(data, 1):
    print(f"Email {i}:")
    print(f"  ID: {email.get('id')}")
    print(f"  Subject: {email.get('subject')}")
    from_info = email.get('from', {})
    if isinstance(from_info, dict):
        print(f"  From: {from_info.get('addr', '')} ({from_info.get('name', '')})")
    else:
        print(f"  From: {from_info}")
    print(f"  Date: {email.get('date')}")
    print(f"  Has attachment: {email.get('has_attachment', False)}")
    body = email.get('body', '')
    if body:
        # Take first 200 chars, strip newlines
        preview = body[:200].replace('\n', ' ').strip()
        print(f"  Body preview: {preview}...")
    print()