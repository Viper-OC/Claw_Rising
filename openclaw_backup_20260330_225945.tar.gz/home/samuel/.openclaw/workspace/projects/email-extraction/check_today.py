#!/usr/bin/env python3
import subprocess
import json
import sys
import os
from datetime import datetime, timezone

def run_himalaya(args):
    cmd = [os.path.expanduser('~/.local/bin/himalaya')] + args
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=20)
        if result.returncode != 0:
            return None
        return result.stdout
    except subprocess.TimeoutExpired:
        return None
    except Exception:
        return None

def get_folders():
    out = run_himalaya(['folder', 'list'])
    if out is None:
        return []
    lines = out.strip().split('\n')
    folders = []
    for line in lines[2:]:
        line = line.strip()
        if not line or line.startswith('+-'):
            continue
        parts = line.split('|')
        if len(parts) >= 2:
            folder = parts[1].strip()
            if folder:
                folders.append(folder)
    return folders

def main():
    folders = get_folders()
    print(f"Checking {len(folders)} folders for emails from today...", file=sys.stderr)
    today = datetime.now(timezone.utc).date()
    found_any = False
    
    for folder in folders:
        args = ['envelope', 'list', '--folder', folder, '--output', 'json', '--page-size', '10']
        out = run_himalaya(args)
        if out is None:
            continue
        try:
            envelopes = json.loads(out)
        except json.JSONDecodeError:
            continue
        today_emails = []
        for env in envelopes:
            date_str = env.get('date')
            if not date_str:
                continue
            try:
                dt = datetime.fromisoformat(date_str.replace('+00:00', '+00:00'))
            except ValueError:
                continue
            if dt.date() == today:
                today_emails.append(env)
        if today_emails:
            found_any = True
            print(f"\n=== Folder: {folder} ===")
            for env in today_emails:
                subject = env.get('subject', '')
                sender = env.get('from', {})
                if isinstance(sender, dict):
                    sender = sender.get('addr', '')
                else:
                    sender = str(sender)
                print(f"  From: {sender}")
                print(f"  Subject: {subject}")
                print(f"  Date: {env.get('date')}")
                print()
    
    if not found_any:
        print("\nNo emails from today found in any folder.", file=sys.stderr)

if __name__ == '__main__':
    main()