#!/usr/bin/env python3
import subprocess
import json
import sys
import os
from datetime import datetime, timezone

def run_himalaya(args):
    cmd = [os.path.expanduser('~/.local/bin/himalaya')] + args
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=20)
        if result.returncode != 0:
            # ignore errors
            return None
        return result.stdout
    except subprocess.TimeoutExpired:
        return None
    except Exception:
        return None

def get_folders():
    out = run_himalaya(['folder', 'list'])
    if out is None:
        return []
    lines = out.strip().split('\n')
    folders = []
    for line in lines[2:]:
        line = line.strip()
        if not line or line.startswith('+-'):
            continue
        parts = line.split('|')
        if len(parts) >= 2:
            folder = parts[1].strip()
            if folder:
                folders.append(folder)
    return folders

def search_folder(folder, sender):
    args = ['envelope', 'list', '--folder', folder, '--output', 'json', '--page-size', '20', 'from', sender]
    out = run_himalaya(args)
    if out is None:
        return []
    try:
        envelopes = json.loads(out)
        return envelopes
    except json.JSONDecodeError:
        return []

def main():
    sender = 'noreply@storypark.com'
    folders = get_folders()
    print(f"Checking {len(folders)} folders for {sender}", file=sys.stderr)
    
    today = datetime.now(timezone.utc).date()
    found = []
    
    for folder in folders:
        envelopes = search_folder(folder, sender)
        if not envelopes:
            continue
        for env in envelopes:
            date_str = env.get('date')
            if date_str:
                try:
                    # parse date like "2026-03-11 17:52+00:00"
                    dt = datetime.fromisoformat(date_str.replace('+00:00', '+00:00'))
                except ValueError:
                    continue
                if dt.date() == today:
                    found.append((folder, env))
    
    if found:
        print(f"\nFound {len(found)} emails from today:", file=sys.stderr)
        for folder, env in found:
            print(f"Folder: {folder}")
            print(f"  ID: {env.get('id')}")
            print(f"  Subject: {env.get('subject')}")
            print(f"  Date: {env.get('date')}")
            print()
    else:
        print("\nNo emails from today found.", file=sys.stderr)
        # Show all envelopes anyway
        for folder in folders:
            envelopes = search_folder(folder, sender)
            if envelopes:
                print(f"\nFolder: {folder} ({len(envelopes)} emails)")
                for env in envelopes[:3]:
                    print(f"  {env.get('date')} {env.get('subject')[:60]}...")

if __name__ == '__main__':
    main()